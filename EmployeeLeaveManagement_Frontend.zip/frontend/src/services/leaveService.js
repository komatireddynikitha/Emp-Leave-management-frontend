const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8080/api/leaves';

async function request(url, options = {}) {
  const response = await fetch(url, options);
  if (!response.ok) {
    const message = await response.text();
    throw new Error(message || `Request failed (${response.status})`);
  }
  if (response.status === 204) return null;
  return response.json();
}

export function getAllLeaves() {
  return request(API_URL);
}

export function getLeavesByEmail(email) {
  return request(`${API_URL}/employee?email=${encodeURIComponent(email)}`);
}

export function applyForLeave(leave) {
  return request(API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(leave),
  });
}

export function updateLeave(id, leave) {
  return request(`${API_URL}/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(leave),
  });
}

export function updateLeaveStatus(id, status) {
  return request(`${API_URL}/${id}/status?status=${encodeURIComponent(status)}`, {
    method: 'PATCH',
  });
}

export function deleteLeave(id) {
  return request(`${API_URL}/${id}`, { method: 'DELETE' });
}
