import { useEffect, useState } from 'react';
import {
  applyForLeave,
  deleteLeave,
  getLeavesByEmail,
} from './services/leaveService.js';
import './App.css';

export default function App() {
  const [emailInput, setEmailInput] = useState('');
  const [email, setEmail] = useState('');
  const [loggedIn, setLoggedIn] = useState(false);
  const [leaves, setLeaves] = useState([]);
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [reason, setReason] = useState('');
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);

  async function loadLeaves(forEmail = email) {
    if (!forEmail) return;
    setBusy(true);
    try {
      setLeaves(await getLeavesByEmail(forEmail));
      setMessage('');
    } catch (error) {
      setMessage(`Could not load leaves. Is the backend running? ${error.message}`);
    } finally {
      setBusy(false);
    }
  }

  useEffect(() => {
    if (loggedIn) loadLeaves(email);
    // Load when the user signs in; subsequent refreshes happen after mutations.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loggedIn]);

  async function login(event) {
    event.preventDefault();
    const normalized = emailInput.trim().toLowerCase();
    if (!normalized) return;
    setEmail(normalized);
    setLoggedIn(true);
    await loadLeaves(normalized);
  }

  async function submitLeave(event) {
    event.preventDefault();
    if (endDate < startDate) {
      setMessage('End date cannot be before start date.');
      return;
    }
    setBusy(true);
    try {
      await applyForLeave({
        employeeEmail: email,
        startDate,
        endDate,
        reason: reason.trim(),
      });
      setStartDate('');
      setEndDate('');
      setReason('');
      setMessage('Leave application submitted.');
      await loadLeaves(email);
    } catch (error) {
      setMessage(`Could not submit application: ${error.message}`);
    } finally {
      setBusy(false);
    }
  }

  async function removeLeave(id) {
    if (!window.confirm('Delete this leave application?')) return;
    setBusy(true);
    try {
      await deleteLeave(id);
      setMessage('Application deleted.');
      await loadLeaves(email);
    } catch (error) {
      setMessage(`Could not delete application: ${error.message}`);
    } finally {
      setBusy(false);
    }
  }

  if (!loggedIn) {
    return (
      <main className="login-page">
        <form className="login-card" onSubmit={login}>
          <div className="logo">EL</div>
          <p className="eyebrow">EMPLOYEE SELF SERVICE</p>
          <h1>Welcome back</h1>
          <p className="muted">Enter your employee email to view leave applications.</p>
          <label htmlFor="email">Employee email</label>
          <input
            id="email"
            type="email"
            placeholder="you@company.com"
            value={emailInput}
            onChange={(event) => setEmailInput(event.target.value)}
            required
          />
          <button className="primary full" type="submit">Continue</button>
          {message && <p className="message error">{message}</p>}
          <small>Demo sign-in only. Add real authentication before production use.</small>
        </form>
      </main>
    );
  }

  const pending = leaves.filter((leave) => leave.status === 'PENDING').length;
  const approved = leaves.filter((leave) => leave.status === 'APPROVED').length;

  return (
    <main className="dashboard">
      <header className="topbar">
        <div className="brand"><span className="logo small-logo">EL</span><div><h1>LeaveDesk</h1><p>Employee portal</p></div></div>
        <button className="button-light" onClick={() => { setLoggedIn(false); setLeaves([]); setMessage(''); }}>Log out</button>
      </header>

      <section className="hero">
        <div><p className="eyebrow light">YOUR WORKSPACE</p><h2>Hi, {email.split('@')[0]} 👋</h2><p>Manage your time off and track your requests.</p></div>
        <div className="hero-mark">✦</div>
      </section>

      <section className="stats">
        <article className="stat-card"><span>Total applications</span><strong>{leaves.length}</strong><small>All your requests</small></article>
        <article className="stat-card"><span>Pending review</span><strong>{pending}</strong><small>Waiting for a decision</small></article>
        <article className="stat-card"><span>Approved</span><strong>{approved}</strong><small>Ready to plan</small></article>
      </section>

      {message && <div className={`message ${message.toLowerCase().includes('could not') ? 'error' : ''}`} role="status">{message}</div>}

      <div className="content-grid">
        <section className="panel">
          <div className="section-heading"><div><p className="eyebrow">NEW REQUEST</p><h2>Apply for leave</h2></div><span className="heading-icon">＋</span></div>
          <form onSubmit={submitLeave}>
            <label htmlFor="start">Start date</label>
            <input id="start" type="date" value={startDate} onChange={(event) => setStartDate(event.target.value)} required />
            <label htmlFor="end">End date</label>
            <input id="end" type="date" min={startDate || undefined} value={endDate} onChange={(event) => setEndDate(event.target.value)} required />
            <label htmlFor="reason">Reason</label>
            <textarea id="reason" rows="4" maxLength="1000" placeholder="Briefly explain your reason..." value={reason} onChange={(event) => setReason(event.target.value)} required />
            <button className="primary full" type="submit" disabled={busy}>{busy ? 'Please wait…' : 'Submit application →'}</button>
          </form>
        </section>

        <section className="panel applications">
          <div className="section-heading"><div><p className="eyebrow">HISTORY</p><h2>My applications</h2></div><button className="button-light refresh" onClick={() => loadLeaves()} disabled={busy}>↻ Refresh</button></div>
          {leaves.length === 0 ? (
            <div className="empty"><span>▤</span><h3>No applications yet</h3><p>Your leave requests will appear here after you submit one.</p></div>
          ) : (
            <div className="leave-list">
              {leaves.map((leave) => (
                <article className="leave-item" key={leave.id}>
                  <div className="leave-date-icon">▣</div>
                  <div className="leave-details"><strong>{leave.startDate} — {leave.endDate}</strong><p>{leave.reason}</p><span className={`status ${String(leave.status).toLowerCase()}`}>{leave.status}</span></div>
                  {leave.status === 'PENDING' && <button className="delete-button" onClick={() => removeLeave(leave.id)} aria-label={`Delete leave ${leave.id}`}>Delete</button>}
                </article>
              ))}
            </div>
          )}
        </section>
      </div>
      <footer>LeaveDesk · Employee Leave Management System</footer>
    </main>
  );
}
